﻿namespace TodoApp
{
    public class TodoService
    {
        private List<TodoItem> todoItems;
        private CsvFileHelper csvFileHelper;
        private string filePath;

        public TodoService(string filePath)
        {
            this.filePath = filePath;
            csvFileHelper = new CsvFileHelper();
            todoItems = csvFileHelper.ReadFromCsv(filePath);
        }

        public List<TodoItem> GetTodoItems()
        {
            return todoItems;
        }

        public void AddTodoItem(TodoItem item)
        {
            todoItems.Add(item);
            csvFileHelper.WriteToCsv(filePath, todoItems);
        }

        public void CompleteTodoItem(string title)
        {
            var item = todoItems.FirstOrDefault(i => i.Title.Equals(title, StringComparison.OrdinalIgnoreCase));
            if (item != null)
            {
                item.IsCompleted = true;
                csvFileHelper.WriteToCsv(filePath, todoItems);
            }
        }

        public void DeleteTodoItem(string title)
        {
            var item = todoItems.FirstOrDefault(i => i.Title.Equals(title, StringComparison.OrdinalIgnoreCase));
            if (item != null)
            {
                todoItems.Remove(item);
                csvFileHelper.WriteToCsv(filePath, todoItems);
            }
        }

        public void PostponeDueDate(string title, DateTime newDueDate)
        {
            var item = todoItems.FirstOrDefault(i => i.Title.Equals(title, StringComparison.OrdinalIgnoreCase));
            if (item != null)
            {
                item.DueDate = newDueDate;
                csvFileHelper.WriteToCsv(filePath, todoItems);
            }
        }
    }

}